
Vishesh Auto Index 4.0
This Release is a complete upgrade of Vishesh Auto Index. Its not* upgradeable from older versions. Since many things are added so the whole database structure has changed and it's designed Only for mp3/mp4 downloading websites. 


Note:- If you want to Upgrade from older version I will help you.



# New Features:
===========================
● Added New Loading JavaScript
● Long Press Link Preview Permission Denied, No one copy Link address
● Every File Have Title, Artist, Category, Label, Lyrics for mp3/mp4
● New Designed In Download File Page
● Bug Fixed for Bitrate Converted Files
● All Pop-ups and annoying ads Removed
● Admin Panel Redesigned
● Install page redesigned
● Security Level Optimization for Admin Panel
● And other some bugs fixed.
● http redirect to http://www


# Old Features:
===========================

● Attractive StyleSheet with Bootstrap CSS and Font awesome Icon
● Faster Loading
● Powerful Updates Manager
● Facebook Page Like Button In Homepage
● Search Form
● Bit Rate Converter(requires FFMPEG)
● Real VideoWatermark (requires GDlibrary)
● Real Image/Icon Watermark
● Upload Icon for every types of file
● AutoMated Sitemap(Full)
● url.txt for Search Engine Crawling (Make Indexed Your webpage on Search Engine)
● Recommended Files in Download Page
● Facebook Comment Plugin
● Social Share Button
● File display system like common download portals.
● Upload/Import via URL
● HTML Updates Editor
● Full SEO Optimized
●  Preview for almost every types of file
● Auto Mp3 Tag Editor(if on from admin panel)


How To Install :-
###################################
1. Download Vishesh Auto Index 4.0 
2. Upload And Extract It on your Online File Manager
3. Now Goto:-
http://yoursitename/install.php
4.Enter your database details  and Website details.
5. Enjoy it.
###################################
How To Access Admin Panel:-
###################################
Admin Panel:- http://yoursite/admin.php
