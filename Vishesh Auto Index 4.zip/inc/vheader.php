<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
error_reporting(0);
if(empty($title))
{
$title = $vk->settings['title'];
}
else
{
$title .= " - {$vk->settings['title']}";
}
$title = escape($title);
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/xml" title="Sitemap" href="sitemap.xml" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0," />
<meta name="author" content="'.$vk->settings['title'].'" /> 
<meta name="revisit-after" content="1 days" /> 
 <meta name="copyright" content="(c) '.$vk->settings['title'].'" /> 
<meta name="distribution" content="global" />
<meta name="classification" content="reference" />
<link href="'.$vk->settings['url'].'/style/vishesh.css" type="text/css" rel="stylesheet"/>
<link href="'.$vk->settings['url'].'/style/vishesh3.css" type="text/css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script language="javascript" src="../js/copyright.js"></script>
<script src="../js/pace.js"></script>
<script>function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}</script>';
include_once('./vishesh/header.vk');
echo'<body>';
echo'<p class="headertop">&nbsp;<span class="style21"><i class="fa-spin fa fa-globe" aria-hidden="true"></i></span>&nbsp;  <a href="'.$vk->settings['url'].'"><font color="white" size="2px" family="Times New Roman"><img src="'.$vk->settings['logo'].'" alt="Vishesh" width="20px" height="20px"/>&nbsp;'.$vk->settings['title'].'</font></a></p>';
 



