<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');
$folder['name'] = 'Home';

$folder['use_icon'] = 0;

$key = $vk->get_input('find');

$pid = $vk->get_input('pid', 1);

$page = isset($vk->input['page']) ? (int)$vk->input['page'] : 1;

$title = 'Search';

$total = 0;



if($pid == 0)

{

$where = '';

}

else

{

$where = 'pid='.$pid.' AND ';

}



include_once('./header.php');



echo '<div class="style19"><b><a href="'.$vk->settings['url'].'">Home</a> &#187; Search</b></div>';





echo '<br/><div class="header">Search</div>';



if(isset($vk->input['action']) && $vk->input['action'] == 'do_search')

{

if(strlen($key) <= 1)

{

$errors[] = 'Search keyword must contain atleast 2 characters.';

}



if(empty($errors))

{

$search_words = explode(" ", $key);



foreach($search_words as $search_word)

{

$where1[] = "`name` LIKE '%$search_word%'";

$where2[] = "`description` LIKE '%$search_word%'";

}

$where_text = "(".implode("AND", $where1).") OR (".implode("AND", $where2).")";



$query = $db->simple_select("files", "fid", "{$where}{$where_text}");

$total = $db->num_rows($query);

}

else

{

show_errors($errors);

}

}



echo '<div class="google_search2">

<form action="'.$vk->settings['url'].'/files/search.html" method="get">

<input type="text" name="find" value="'.escape($key).'" />

<input type="hidden" name="pid" value="'.$pid.'" />

<input type="hidden" name="action" value="do_search" />

<input type="submit" value="Search" /></form></div>';

echo'<p class="header">Search Result In Folder & Files</p>';

if($total > 0)

{

$start = ($page-1)*$vk->settings['files_per_page'];



$query = $db->simple_select("files", "fid, name, title, artist, size, isdir, path, tag, dcount", "{$where}{$where_text}", ['order_by' => 'isdir DESC, disporder ASC', 'limit_start' => $start, 'limit' => $vk->settings['files_per_page']]);



while($file = $db->fetch_array($query))

{

if($file['isdir'] == 1)

{

echo '<p class="djnew"><i class="fa fa-folder" aria-hidden="true"></i> <a href="'.$vk->settings['url'].'/list/'.$file['fid'].'/'.convert_name($file['name']).'.html">'.escape($file['name']).'';



if($vk->settings['show_filecount'])

{

$counter = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%' AND `isdir` = '0'");

echo ' ['.$db->num_rows($counter).'] ';

}



if($file['tag'] == 1)

{

echo ' '.vk_img('new.png', "New").'';

}

else if($file['tag'] == 2)

{

echo ' '.vk_img('updated.png', "Updated").'';

}



echo '</div></a></p>';

}

else



{

echo '

<p class="djnew"><div class="fl"><a href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="dj"><div><div>';



if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';

}

else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';

}

else 

{

echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="60" height="65" />';

}



echo '</div><div>'.escape($file['title']).'
&nbsp; [<font color="red">'.escape($file['artist']).'</font>]
';



if($file['tag'] == 1)

{

echo ' '.vk_img('new.png', "New").'';

}

else if($file['tag'] == 2)

{

echo ' '.vk_img('updated.png', "Updated").'';

}



echo '<br /><span>['.convert_filesize($file['size']).']</span><br /><span></span></div></div></a></div></p>';

}

}

 $url = "{$vk->settings['url']}/search.php?key=".escape($key)."&pid={$pid}";

echo pagination($page, $vk->settings['files_per_page'], $total, $url);

}

else

{

echo '<div class="style3">No results found</div>';

}





include_once('./footer.php');

