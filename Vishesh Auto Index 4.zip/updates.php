<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

$title = 'All Updates';
$folder = [];
$page = isset($vk->input['page']) ? (int)$vk->input['page'] : 1;
$folder['name'] = 'Home';
$folder['use_icon'] = 0;

include_once('./header.php');

include_once('./assets/ads/bcategory.php');

echo '<p class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; All Updates</p>';

// Category title
echo '<div class="header">ALL UPDATES</div>';

include_once('./assets/ads/acategory.php');



$query = $db->simple_select("files", "fid", "isdir='0'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($page-1)*$vk->settings['files_per_page'];

$options = ['order_by' => 'time DESC', 'limit_start' => $start, 'limit' => $vk->settings['files_per_page']];

$query = $db->simple_select("files", "fid, name, title, artist, tag, size, path, pid, dcount", "isdir='0'", $options);
while($file = $db->fetch_array($query))
{
if($file['pid'] != 0)
{
$query2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query2);
}

echo '<p class="fl"><a href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="dj" >';

if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else 
{
echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="60" height="65" />';
}

echo '<b>'.escape($file['title']).'
<font color="red">['.escape($file['artist']).']</font></b>';
if($file['tag'] == 1)
{
echo ' '.vk_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.vk_img('updated.png', "Updated").'';
}
echo '<span><font color="green">['.convert_filesize($file['size']).']</font></span>';
echo '</a></p>';
}
$url = "{$vk->settings['url']}/newitems/{page}.html";

echo pagination($page, $vk->settings['files_per_page'], $total, $url);
}
else
{
echo '<div class="style3">No Update Found!</div>';
}

include_once('./assets/ads/afilelist.php');

echo '<p class="dj">&#187; <b><a href="'.$vk->settings['url'].'">Home</a></b></p>';

include_once('./footer.php');
