<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
echo '<p class="header">Services</p>
<p class="djnew">&#187; <a href="/top/0.html"> Top 20 Files</a></p>
<p class="djnew">&#187;  <a href="/source.html"> Source Code Viewer</a></p>';
echo '<p class="header">Our Online Site Partner</p>';
include_once('./vishesh/sponser.vk');
echo'<p class="header"> Contacts Us</p>
<p class="djnew"> &#187;  <a href="/policy.html"> Our Policy</a><span class="style19"> [Regarding CopyRight Content]</span>
<p class="djnew"> &#187;  <a href="mailto:'.$vk->settings['email'].'">Mail Us</a><span class="style19"> [Feedback/Any Other Problem]</span>
</p>';
echo'
<div class="header_2"><font color="black"><script>var x = navigator; document.write("" + x.userAgent);</script></font></div><br/>';