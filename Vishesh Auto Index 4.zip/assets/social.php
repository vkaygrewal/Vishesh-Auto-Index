<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
echo'<br/><div class="header">Share This File</div>
<a href="https://www.facebook.com/sharer/sharer.php?u='.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" target="_blank" rel="noopener">
  <i class="fa fa-facebook-square" style="font-size:48px"></i>
</a>
 <a class="twitter-share-button"
  href="https://twitter.com/intent/tweet?text='.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html">
  <i class="fa fa-twitter-square" style="font-size:48px" ></i>
 </a>

<a href="whatsapp://send?text='.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" data-action="share/whatsapp/share">
  <i class="fa fa-whatsapp" style="font-size:48px" ></i>
</a>
 
 <a href="https://plus.google.com/share?url='.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html">
 <i class="fa fa-google-plus-square" style="font-size:48px" ></i>
</a>  
<a href="javascript:;" onclick="window.print()">
  <i class="fa fa-print" style="font-size:48px" ></i>
</a>
</div>';
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<?php
echo'<br/><p class="header">Leave A Comment About This File</p>
<div class="fb-comments" data-href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" data-width="100" data-numposts="5"></div>';
?>
<?php
echo'<br/><div class="header">Description</div>
<p class="djnew"><font color="green">'.$file['description'].'</font></p>';