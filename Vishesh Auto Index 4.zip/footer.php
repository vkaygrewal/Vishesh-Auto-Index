<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
include_once('./assets/ads/footer.php');
echo'<br/><div class="headerbottom"><a href="'.$vk->settings['url'].'/index.html" alt="Footer"><font color="white">A '.$vk->settings['title'].' Creation </font></a>&#169;&nbsp;' ?>

<?php echo date("Y");?>
<script language="javascript" src="../js/copyright.js"></script>
<script src="../js/pace.js"></script>
</html>
</body>