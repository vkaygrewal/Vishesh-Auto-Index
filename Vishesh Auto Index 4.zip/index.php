<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

if(preg_match("#index.php#s",''.$_SERVER['REQUEST_URI'].'')){header('HTTP/1.1 301 Moved Permanently'); header('Location: index.html');}
$title = '';
$folder = [];
$pid = $vk->get_input('pid', 1);
$page = isset($vk->input['page']) ? (int)$vk->input['page'] : 1;
$sort = isset($vk->input['sort']) ? $vk->input['sort'] : $vk->settings['sort'];

if($pid != 0)
{
$query = $db->simple_select("files", "fid, name, use_icon, path, description", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!is_array($folder))
{
header('Location: '.$vk->settings['url']);
exit;
}

$title = $folder['name'];
$folder['name'] = escape($folder['name']);
}
else
{
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
}

include_once('./inc/vheader.php');

// Updates
if($pid == 0)
{
echo '<div class="style3"><div class="container"><img src="'.$vk->settings['logo'].'" alt="'.$vk->settings['title'].' logo" class="image" width="160" height="320"/> 
<div class="middle">
    <div class="text">'.$vk->settings ['title'].' logo </div></div></div>
<br/><font color="black">Welcome On  </font><font color="green">Mobile&#39;s Heaven</font>
<br/><font color="black">   Save BookMark Us  As '.$vk->settings['title'].'</font> <a href="/disclaimer.html">Disclaimer</a></div>'; ?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.0';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php
echo '<br/><div class="fb-like" data-href="https://facebook.com/'.$vk->settings['fbpagename'].'" data-width="200" data-layout="standard" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div><br/>';
echo'<div class="header">Advertisement</div>';
include_once('./assets/ads/blogo.php');
echo'</div><div class="header"><center><span class="style3"><script language="javascript" src="/js/date2.js"></script></div></center></div>
<br/><div class="margin">'; 
$options = ['order_by' => 'uid', 'order_dir' => 'desc', 'limit' => $vk->settings['updates_on_index']];
$query = $db->simple_select("updates", "description", "status='A'", $options);
$total = $db->num_rows($query);

if($total != 0)
{
while($update = $db->fetch_array($query))
{
echo '<div>&#187;  '.$update['description'].'</div><br/>';
} 
}
else
{
echo '<div class="style3">No updates!</div>';
}
echo '<div class="djnew"> &#187; <a href="/updates/1.html"> All Updates</a> [Sometimes We Don&#39;t Update On Homepage]</div>
</div>';
}


include_once('./assets/ads/bcategory.php');
if($vk->settings['show_searchbox'])
{
echo '<div class="google_search2">
<form method="post" action="'.$vk->settings['url'].'/files/search.html">
<input type="text" name="find" size="20" />
<input type="hidden" name="pid" value="'.$pid.'" />
<input type="hidden" name="action" value="do_search" />
<input type="submit" value="Search" />
</form>
</div>';
}

// Category 
if($pid == 0)
{
echo '<div class="header">Downloads Menu</div><br/>';
}
else
{
echo '<div class="header"><font color="red"><i class="fa fa-folder" aria-hidden="true"></i> </font>  '.$folder['name'].'</div>
<div class="discription">'.$folder['description'].'</div>';

if(file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<div class="djnew" align="center"><img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.$folder['name'].'" height="150" width="150"/></div>';
}
}

$sort_links = [['value' => 'new2old', 'name' => 'New'], ['value' => 'a2z', 'name' => 'A to Z'], ['value' => 'z2a', 'name' => 'Z to A'], ['value' => 'download', 'name' => 'Download']];

switch($sort)
{
case 'a2z':
$order = 'name ASC';
break;
case 'z2a':
$order = 'name DESC';
break;
case 'download':
$order = 'dcount DESC';
break;
default:
$order = 'time DESC';
break;
}

if($pid != 0)
{
echo '<div class="style21" align="center" >';

$bar = '';

foreach($sort_links as $sort_link)
{
if($sort_link['value'] == $sort)
{
echo ''.$bar.'<a href="'.$vk->settings['url'].'/list/'.$folder['fid'].'/'.$sort_link['value'].'/'.$page.'/'.convert_name($folder['name']).'.html" class="active">'.$sort_link['name'].'</a>';
}
else
{
echo ''.$bar.'<a href="'.$vk->settings['url'].'/list/'.$folder['fid'].'/'.$sort_link['value'].'/'.$page.'/'.convert_name($folder['name']).'.html">'.$sort_link['name'].'</a>';
}

$bar = ' | ';
}

echo '</div><br/>';
}

include_once('./assets/ads/bfilelist.php');

$query = $db->simple_select("files", "fid", "pid='{$pid}'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($page-1)*$vk->settings['files_per_page'];

$options = ['order_by' => 'isdir DESC, disporder ASC, '.$order.'', 'limit_start' => $start, 'limit' => $vk->settings['files_per_page']];

$query = $db->simple_select("files", "fid, name, title, artist, isdir, tag, path, size, dcount", "pid='{$pid}'", $options);
while($file = $db->fetch_array($query))
{
if($file['isdir'] == 1)
{
echo'<div class="djnew"> <a href="'.$vk->settings['url'].'/list/'.$file['fid'].'/'.convert_name($file['name']).'.html"><div>
<font color="red"><i class="fa fa-folder" aria-hidden="true"></i> </font> '.escape($file['name']).'';

if($vk->settings['show_filecount'])
{
$counter = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%' AND `isdir` = '0'");
echo ' ['.$db->num_rows($counter).'] ';
}

if($file['tag'] == 1)
{
echo ' '.vk_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.vk_img('updated.png', "Updated").'';
}

echo '</div></br></a></div>';
}
else
{
echo '<div class="fl"><a href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="fileName"><div><div>';

if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'" width="80" height="80" />';
}
else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="80" height="80" />';
}
else 
{
echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="80" height="80" />';
}

echo '</div><div>'.escape($file['title']).'
<font color="red">['.escape($file['artist']).']</font>';

if($file['tag'] == 1)
{
echo ' '.vk_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.vk_img('updated.png', "Updated").'';
}
echo '<br /><span>['.convert_filesize($file['size']).']</span><br /><span>'.$file['dcount'].' Download</span></div></div></a></div>';}
}

$url = "{$vk->settings['url']}/list/{$pid}/{$sort}/{page}/".convert_name($folder['name']).".html";

echo pagination($page, $vk->settings['files_per_page'], $total, $url);
}
else
{
echo '<div class="style21">No Any File/Folder Created!</div>';
}


include_once('./assets/ads/acategory.php');


// Services
if($pid == 0)
{
include_once('./assets/services.php');
}

if($pid != 0)
{
echo '<p class="header">Related Tags</p>
<div class="style3"><span style="font-size:10px;"><span style="color:#006400;">Tags :</span> '.$folder['name'].' Download, '.$folder['name'].' Free Download, '.$folder['name'].' All Mp3 Song Download, '.$folder['name'].' Movies Full Mp3 Songs, '.$folder['name'].' video song download, '.$folder['name'].' Mp4 HD Video Song Download, '.$folder['name'].' Download Ringtone, '.$folder['name'].' Movies Free Ringtone, '.$folder['name'].' Movies Wallpapers, '.$folder['name'].' HD Video Song Download</div>';
}

if($pid != 0)
{

$_dr = '';

echo '<br/><div class="style21"><a href="'.$vk->settings['url'].'/index.html">Home</a>';

foreach(explode('/', substr($folder['path'], 7)) as $dr)
{
$_dr .= "/".$dr;
$path = "/files{$_dr}";

$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);

if($pid == $id['fid'])
{
echo ' &#187; '.escape($id['name']).'';
}
else
{
echo ' &#187; <a href="'.$vk->settings['url'].'/list/'.$id['fid'].'/'.$vk->settings['sort'].'/1.html">'.escape($id['name']).'</a>';
}
}
echo '</div>';
}

include_once('./footer.php');
