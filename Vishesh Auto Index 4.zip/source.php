<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

$title = 'Source Code Viewer From Vishesh Auto Index';

include_once('./header.php');


if(isset($_GET['url']) && substr($_GET['url'],0,7) == 'http://') 
{ 
$source = file_get_contents($_GET['url']);
echo '<div><font color="red">Source Code Viewer</font></div><div>'.htmlspecialchars($source).'</div>'; 
} 

echo '<div class="google_search2"><form action="'.$_SERVER['PHP SELF'].'" method="get"> 
<br/><br/><div> 
<center>URL For Source Code:- </center><br/>
<input type="text" name="url" value="http://" /> 
<input type="submit" value="Get" /> 
</div> 
</form><br/>'; 
echo'<p class="djnew"> &#9679; Please Use <span class="style21">http://</span> instead of <span class="style19">https://</span><br/>
For e.g.:- <span class="style21"><a href="http://Visheshgrewal.blogspot.com">http://www.vishesh.tk</a></span><font color="#7EC0EE"> <i class="fa fa-check-circle" aria-hidden="true"></i></font></p>';
include_once('./footer.php');
