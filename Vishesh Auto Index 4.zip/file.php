<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);

include_once('./inc/init.php');



$tag = $vk->get_input('tag', 1);

$fid = $vk->get_input('fid');



$query = $db->simple_select("files", "*", "fid={$fid}");

$file = $db->fetch_array($query);



if(!$file)

{

header('Location: '.$vk->settings['url'].'');

exit;

}



$input = VK_ROOT.$file['path'];

$info = pathinfo($input);



$db->query("UPDATE ".TABLE_PREFIX."files SET views=views +1 WHERE fid='".$file['fid']."'");





$title = $file['name'];

include_once('./header.php');





$_dr = '';



echo '<div class="style19"><b><a href="'.$vk->settings['url'].'/">Home</a>';



foreach(explode('/', substr($file['path'], 7)) as $dr)

{

$_dr .= "/".$dr;

$path = "/files{$_dr}";



$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");

$id = $db->fetch_array($query);



if($fid == $id['fid'])

{

echo ' &#187; '.escape($id['name']).'</b>';

}

else

{

echo ' &#187; <a href="'.$vk->settings['url'].'/list/'.$id['fid'].'/'.$vk->settings['sort'].'/1.html">'.escape($id['name']).'</a>';

}

}

echo '</div>';



if($vk->settings['show_searchbox'])

{

echo '<div class="google_search2">

<form method="post" action="'.$vk->settings['url'].'/files/search.html">

<input type="text" name="find" size="20" />

<input type="hidden" name="pid" value="'.$pid.'" />

<input type="hidden" name="action" value="do_search" />

<input type="submit" value="Search" />

</form>

</div>';

}

$query = $db->simple_select("files", "*", "fid='{$file['pid']}'");

$folder = $db->fetch_array($query);

?>

<div id="fb-root"></div>

<script>(function(d, s, id) {

  var js, fjs = d.getElementsByTagName(s)[0];

  if (d.getElementById(id)) return;

  js = d.createElement(s); js.id = id;

  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.0';

  fjs.parentNode.insertBefore(js, fjs);

}(document, 'script', 'facebook-jssdk'));</script>

<?php

echo'<div class="fb-like" data-href="https://facebook.com/'.$vk->settings['fbpagename'].'" data-width="200" data-layout="standard" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div><br/>';

echo '<br/><p class="header">Download '.$file['name'].' [<span class="style21">'.$file['artist'].'</span>] </p><center><div class="album_img"><div class="container"><div class="visheshout">';

if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'"  class="image" width="120" height="65" />';

}

else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="120" height="65" />';

}

else

{

echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="120" height="65"  /></div></div><br/>';

}

echo'
<div class="middle">
    <div class="text">'.escape($file['title']).'</div></div></div></div>';


echo'</center><div class="header_2"><div class="updates"><b><div><font color="red">Title</font> :- <font color="green"> '.escape($file['title']).'</font></div><br/>
<div><font color="red">Artist</font> :- <font color="green"> '.escape($file['artist']).'</font></div><br/>
<div><font color="red">lyrics</font> :- <font color="green"> '.escape($file['lyrics']).'</font></div><br/>
<div><font color="red">Category</font> :- <font color="green"> '.escape($file['music']).'</font></div><br/>
<div><font color="red">Label</font> :- <font color="green"> '.escape($file['label']).'</font></div><br/>';

echo '<div><font color="red">Views </font> :- <font color="green"> '.escape($file['views']).' </font></div><br/>

<div><font color="red">Downloads</font> :- <font color="green"> '.escape($file['dcount']).' </font></div><br/>
<div><font color="red">Size</font> :- <font color="green"> '.convert_filesize($file['size']).'</font></div><br/>

<div><font color="red">Added On </font> :- <font color="green"> '.date("d-m-y", $file['time']).' </font></div></div></div></div></b>'; 
include_once('./assets/ads/aplay.php');

if($file['isdir'] == 0)

{

$ext = pathinfo($file['path'], PATHINFO_EXTENSION);



if($ext == 'mp4')

{

echo '<p class="header">Play This Video Online</p>';

{

$path = VK_ROOT.$file['path'];

}

echo ' <video width="340" height="200" controls ><source src="'.$vk->settings['url'].'/file/download/'.$file['fid'].'.html" type="video/mp4">Your browser does not support the video tag.</video>';

}}



if($file['isdir'] == 0)

{

$ext = pathinfo($file['path'], PATHINFO_EXTENSION);

if($ext == 'mp3')

{{

$path = VK_ROOT.$file['path'];

}

echo '<p class="header">Play This Song Online</p>

<audio controls><source src="'.$vk->settings['url'].'/file/download/'.$file['fid'].'.html" type="audio/mpeg" width="100%" border="0"> Your browser does not support the audio tag.</audio><br/>';

}}
include_once('./assets/ads/bplay.php');

if($vk->settings['related_files'])

{

echo '</div></div><br/><div class="header_2">Recommended For You</div>';



$options = ['order_by' => 'time DESC', 'limit' => $vk->settings['related_files_per_page']];



$query = $db->simple_select("files", "fid, name, title, artist, tag, size, path,  dcount", "pid='{$file['pid']}' AND isdir='0'", $options);

while($rfile = $db->fetch_array($query))

{

echo '<div class="fl"><a href="'.$vk->settings['url'].'/download/'.$rfile['fid'].'/'.convert_name($rfile['name']).'.html" class="djnew">';


if(file_exists(VK_ROOT.'/thumbs/'.$rfile['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$rfile['fid'].'.png" alt="'.escape($rfile['name']).'" width="60" height="65" />';

}

else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($rfile['name']).'" width="60" height="65" />';

}

else 

{

echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($rfile['path']).'&fid='.$rfile['fid'].'" alt="'.escape($rfile['name']).'" width="60" height="65" />';

}



echo '<b>'.escape($rfile['title']).'&nbsp;
<font color="red">['.escape($rfile['artist']).']</font></b>';





echo '</a></div></div>';

}

}
echo'<div class="header">Download File</div>';
include_once('./assets/ads/bdown.php');
echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/file/download/'.$file['fid'].'.html" alt="'.escape($file['name']).'"><b>Download  '.escape($file['title']).'</a> </div>
<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/ads.php" alt="'.escape($file['name']).'" >Download '.escape($file['title']).' Fast</b></a></div>';
If($info['extension'] == 'mp3')
{
$output = "{$info['dirname']}/64kb-{$info['filename']}.{$info['extension']}";
$output2 = "{$info['dirname']}/128kb-{$info['filename']}.{$info['extension']}";
$output3 = "{$info['dirname']}/192kb-{$info['filename']}.{$info['extension']}";
$output4 = "{$info['dirname']}/320kb-{$info['filename']}.{$info['extension']}";

if(file_exists($output))
{
$output = str_replace(VK_ROOT, '', $output);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output.'"><b>Download as 64Kbps</b></a></div>';
}

if(file_exists($output2))
{
$output2 = str_replace(VK_ROOT, '', $output2);

echo '<div><font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output2.'"><b>Download as 128Kbps</b></a></div>';
}

if(file_exists($output3))
{
$output3 = str_replace(VK_ROOT, '', $output3);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output3.'"><b>Download as 192Kbps</b></a></div>';
}

if(file_exists($output4))
{
$output4 = str_replace(VK_ROOT, '', $output4);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output4.'"><b>Download as 320Kbps</b></a></div>';
}

/*
$zip = "{$folder['path']}/".convert_name($folder['name']).".zip";



if(!file_exists($zip))

{

$zipp = new ZipArchive();



if($zipp->open(VK_ROOT.$zip, ZIPARCHIVE::CREATE)===TRUE)

{ 

$query = $db->simple_sekect("files", "path", "pid='".$folder['fid']."' AND isdir=1");

while($ad = $db->fetch_array($query))

{

$zipp->addFile(VK_ROOT.$ad['path']);

}

$zipp->close();

}

}



echo '<div class="fl dwnLink" align="center"><a class="dwnLink" href="'.$vk->settings['url'].''.$zip.'"><b>[Download Full Album 320kbps.zip]<br/>Size : '.convert_filesize(filesize($zip)).'</b></a></div></div>';
*/

}
include_once('./assets/ads/adown.php');


echo'<div class="header">Direct URL</div>
<input type="text" value="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" id="myInput">
<div class="tooltip">
<button onclick="myFunction()" onmouseout="outFunc()">
<div class="style21"> Copy Link</div></button>
</div>';

include_once('./assets/social.php');

echo '<div class="header">Related Tags</div>

<p class="djnew"><font color="red">'.$file['name'].' Download, '.$file['name'].' Free Download, '.$file['name'].' All Mp3 Song Download, '.$file['name'].' Movies Full Mp3 Songs, '.$file['name'].' video song download, '.$file['name'].' Mp4 HD Video Song Download, '.$file['name'].' Download Ringtone, '.$file['name'].' Movies Free Ringtone, '.$file['name'].' Movies Wallpapers, '.$file['name'].' HD Video Song Download</font></p>';





echo '<p class="dj">&#187; <b><a href="'.$vk->settings['url'].'/index.html">Home</a></b></p>';

include_once('./footer.php');

