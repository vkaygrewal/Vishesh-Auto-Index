<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
?>
<br/>
<div class="headerbottom"> <?php echo date('Y'); ?>  &#169; <a href="http://vishesh.tk/" alt="#"><font color="white">A Vishesh Grewal Project</font></a></div>
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
</body>
</html>

