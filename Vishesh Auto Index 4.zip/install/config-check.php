<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
include_once("./header.php");
?>
<div class="header_2">	<div class='header'><center><div class="catRow"><apan class="style21">Server Configuration</span></div></center></div>

		<div class="info">

		<div class="sep">

		PHP Version: <?php 

		$php=phpversion();

		echo"<b>$php</b>";

		if($php = 5.6){

		echo '<span class="good">GOOD!</span>';

		}

		else{

		echo '<span class="bad">BAD!</span>';

		}

		?>

		<div id="red">PHP version must be 5.6</div>

		</div>

				<div class="sep">

		cURL Library: <?php 



		if(function_exists('curl_version')){

		echo '<b>Found</b> <span class="good">GOOD!</span>';

		}

		else{

		echo '<b>Not Found</b> <span class="bad">BAD!</span>';

		}

		?>

		<div id="red">if cURL library not installed allow_url_fopen should be <em>on</em></div>

		</div>

		<div class="sep">

		allow_url_fopen: <?php 



		if(ini_get('allow_url_fopen')){

		echo '<b>On</b> <span class="good">GOOD!</span>';

		}

		else{

		echo '<b>Off</b> <span class="bad">BAD!</span>';

		}

		?>

		<div id="red">required if cURL is not installed</div>

		</div>	

		<div class="sep">

		GD Library: <?php 



		if(extension_loaded('gd') && function_exists('gd_info')){

		echo '<b>Found</b> <span class="good">GOOD!</span>';

		}

		else{

		echo '<b>Not Found</b> <span class="bad">BAD!</span>';

		}

		?>

		<div id="red">required for image watermarking</div>

		</div>

<div class="sep">

		FFMPEG: 

<?php

$command = 'ffmpeg -version';

$path = '/tmp';



exec($command, $path, $returncode);

if ($returncode == 127)

{

 echo '<b>Not Found</b> <span class="bad">BAD!</span>';

 die();

}

else

{

 echo '<b>Found</b> <span class="good">GOOD!</span>';

}

?>	<div id="red">required for MPEG bit conversion.	</div>	<br/>
<div class="sep">Vishesh Auto Index Check your server ffmpeg not for your hosting account.</div>

</div>

		</div></div>

