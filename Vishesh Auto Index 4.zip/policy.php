<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

$title = 'We Provide Latest And Xclusive Stuf For Your Mobile Keep In Mind From Vishesh Auto Index';

include_once('./header.php');
include_once('./vishesh/policy.vk');
include_once('./footer.php');