<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");
$version = 4.0;
// Login
if(isset($vk->input['action']) && $vk->input['action'] == 'do_login')
{
$pass = sha1($vk->input['password']);

if($pass == $vk->settings['adminpass'])
{
if($vk->get_input('remember', 1) == 1)
{
vk_setcookie("pass", $pass);
}

$_SESSION['adminpass'] = $pass;
}

}

$title = 'Admin control panel Vishesh Auto Index';
include_once("./header.php");
echo'<div class="header_2">
<div class="header"><center>Welcome Admin!<br/>
<div class="catRow"><span class="style21">Version :- </span><span class="style21"> '.$version.' [<span="good"> Only For Mp3/Mp4 Websites]</span></span></div>
</center></div><br/>';
if(!is_admin())
{
echo '<p class="header">Admin Login</p>
<div class="google_search2">
<form method="post" action="#">
<div>Password:</div>
<div><input type="password" name="password" /></div>
<div><input type="checkbox" name="remember" value="1" /> Remember Me</div><br/>

<div><input type="hidden" name="action" value="do_login" />
<input type="submit" value="Login" /></div>
</form>
</div></div>';
}
else
{
echo '<div class="header_2"><p class="header">Admin Cp</p>

<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings">Settings Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/ads.php">Ads Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/files"> File Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/editor-more.php">Head Tag, Disclaimer, Policy, Partner Site Editor</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings/change.php"> Change Password</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/scan.php"> Scan Folder</a></p></div></div>';
echo'
<p class="djnew">&#187; <a href="http://vkay.cf">Vishesh Grewal Portfolio</a></p>
<p class="djnew">&#187; <a href="http://visheshgrewal.blogspot.com">Vishesh Grewal Blog</a></p>
<p class="djnew">&#187; <a href="mailto:vkaygrewal.gmail.com">Send Feedback/Suggestion/Problem Via Email</a></p>

';
}
include_once("./footer.php");
