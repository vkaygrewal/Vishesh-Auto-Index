<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");
$version = 4.0;
// Login
if(isset($vk->input['action']) && $vk->input['action'] == 'do_login')
{
$pass = sha1($vk->input['password']);

if($pass == $vk->settings['adminpass'])
{
if($vk->get_input('remember', 1) == 1)
{
vk_setcookie("pass", $pass);
}

$_SESSION['adminpass'] = $pass;
}

}

$title = 'Admin control panel Vishesh Auto Index';
include_once("./header.php");
echo'<div class="header_2">
<div class="header"><center>Welcome Admin!<br/>
<div class="catRow"><span class="style21">Version :- </span><span class="style21"> '.$version.' [<span="good"> Only For Mp3/Mp4 Websites]</span></span></div>
</center></div><a href="https://api.whatsapp.com/send?phone=+919541049220&text=I want To buy Vishesh Auto Index Ads Free Version">
<button class="btn" style="width100%">Get Vishesh Auto Index Ads Free Version at Only RS.500/-</button></a>
';
if(!is_admin())
{
echo '<p class="header">Admin Login</p>
<div class="google_search2">
<form method="post" action="#">
<div>Password:</div>
<div><input type="password" name="password" /></div>
<div><input type="checkbox" name="remember" value="1" /> Remember Me</div><br/>

<div><input type="hidden" name="action" value="do_login" />
<input type="submit" value="Login" /></div>
</form>
</div></div>';
}
else
{
echo'<a href="https://client.googiehost.com/aff.php?aff=3687"><img src="https://googiehost.com/banner/728_90_2.gif" style="height:90px;width:728px;" border="0" alt="Free Hosting" /></a>';

echo '<div class="header_2"><p class="header">Admin Cp</p>
<a href="http://wap4dollar.com/refer.php?refer=pkfenmxmgz"> Earn @ Wap4dollar.Com </a>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings">Settings Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/ads.php">Ads Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/files"> File Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/editor-more.php">Head Tag, Disclaimer, Policy, Partner Site Editor</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings/change.php"> Change Password</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/scan.php"> Scan Folder</a></p></div>
 
<br/>';
}
include_once("./footer.php");
