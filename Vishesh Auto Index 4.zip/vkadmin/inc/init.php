<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
require_once(dirname(dirname(dirname(__FILE__)))."/inc/init.php");
