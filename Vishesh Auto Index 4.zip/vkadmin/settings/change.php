<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include('../inc/init.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$message = '';
$title = "Change Password";

if(isset($vk->input['action']) && $vk->input['action'] == 'do_change' && $vk->request_method == 'post')
{
$len = strlen($vk->input['newpass']);

if(!empty($vk->input['newpass']) && $len >= 5)
{
if($vk->settings['adminpass'] == sha1($vk->input['oldpass']))
{
$db->update_query("settings", ['value' => $db->escape_string(sha1($vk->input['newpass']))], "name='adminpass'");
vk_unsetcookie('pass');

if(function_exists('rebuild_settings'))
{
rebuild_settings();
}

header('Location: '.$vk->settings['adminurl'].'');
exit;
}
else
{
$message = 'Old password incorrect';
}
}
else
{
$message = 'New password must contain atleast 5 characters';
}
}

include('../header.php');

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>Change Password</b></div><br/>';
echo "<h1>Change Password</h1>";

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div>';
}

echo '<div class="google_search2">
<form method="post" action="#">
<div><b>Old Password:</b>
<div><input type="password" name="oldpass" value="" /></div></div><br/>
<div><b>New Password:</b>
<div><input type="password" name="newpass" value="" /></div></div><br/>
<div><input type="hidden" name="action" value="do_change" />
<input type="submit" name="change" value="Change Password" /></div>
</form>
</div>';
include('../footer.php');
