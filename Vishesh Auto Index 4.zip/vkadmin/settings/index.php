<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include('../inc/init.php');
if(!is_admin()){header('Location: '.$vk->settings['url'].'');exit;}$title = 'Settings Management';include('../header.php');echo '<br/><div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>Settings</b></div>';echo '<br/><p class="header">Settings</p>';$options = ['order_by'=>'disporder', 'order_dir'=>'asc'];$query = $db->simple_select("settingsgroups", "*", "", $options);while($setting = $db->fetch_array($query)){echo '<div class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings/setting.php?gid='.$setting['gid'].'">'.$setting['title'].'</a><div style="padding: 3px" class="djnew">'.$setting['description'].'</div></div><br/>';}include('../footer.php');
