<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include('../inc/init.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$gid = $vk->get_input('gid', 1);

$query = $db->simple_select("settingsgroups", "title", "gid='{$gid}'");
$settinggroup = $db->fetch_array($query);

if(!is_array($settinggroup))
{
header('Location: '.$vk->settings['adminurl'].'/settings');
exit;
}

$message = '';
$title = "Edit - {$settinggroup['title']}";

if(isset($vk->input['action']) && $vk->input['action'] == 'do_save' && $vk->request_method == 'post')
{
foreach($vk->input as $key => $value)
{
if($key == 'action')
{
continue;
}

$data = ['value' => $db->escape_string($value)];

$db->update_query("settings", $data, "gid='{$gid}' && name='".$db->escape_string($key)."'");
}

if(function_exists('rebuild_settings'))
{
rebuild_settings();
}

$message = 'Settings saved sucessfully.';
}

include('../header.php');
echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>Settings</b></div><br/>';


echo "<h1>{$settinggroup['title']}</h1>";

if(!empty($message))
{
echo '<div class="style19">'.$message.'</div>';
}

echo '<div>
<form method="post" action="#">
<input type="hidden" name="gid" value="'.$gid.'" />';

$options = ['order_by'=>'disporder', 'order_dir'=>'asc'];

$query = $db->simple_select("settings", "*", "gid='{$gid}'", $options);
while($setting = $db->fetch_array($query))
{
echo '<div class="djnew"><font color="green">'.$setting['title'].'</font>:- <font color="red">'.$setting['description'].'</font></div>';

if($setting['type'] == 'text')
{
echo '<div class="google_search2"><input type="text" name="'.$setting['name'].'" value="'.escape($setting['value']).'" />
</div>';
}

else if($setting['type'] == 'yesno')
{
echo '<div><span class="green"><input type="radio" name="'.$setting['name'].'" value="1"'.($setting['value'] == 1 ? ' checked="vkaygrewal"' : '').' /> Yes</span> <span class="pink"><input type="radio" name="'.$setting['name'].'" value="0"'.($setting['value'] == 0 ? ' checked="vkaygrewal"' : '').' /> No</span></p>';
}

else if($setting['type'] == 'select')
{
echo '<div><select name="'.$setting['name'].'">';

$type = explode("\n",$setting['optionscode']);

for($i=1;$i<count($type);$i++)
{
$val = explode("=",$type[$i]);

if(trim($val[0]) != '')
{
echo "<option value='".$val[0]."'".($setting['value'] == $val[0] ? " selected='vkaygrewal'" : "").">".escape($val[1])."</option>";
}
}
echo '</select>';
}
echo '</div>';
}
echo '<div class="google_search2"><input type="hidden" name="action" value="do_save" /><input type="submit" name="save" value="Save" /></div>
</form>
</div></div></div>';


include('../footer.php');
