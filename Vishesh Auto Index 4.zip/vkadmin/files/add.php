<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("../inc/init.php");

include_once(VK_ROOT."/inc/class_watermark.php");

 if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$pid = $vk->get_input('pid', 1);

$title = 'Add Folder';
$errors = [];

include_once('../header.php');


echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187;  <a href="'.$vk->settings['adminurl'].'/files">File Manager</a> &#187;  <b>Add Folder</b></div><br/>';

echo '<h1>Add Folder</h1>';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_add' && $vk->request_method == 'post')
{
$name = $vk->get_input('name');

if(empty($name))
{
$errors[] = 'Folder can not be empty!</div>';
}

$query = $db->simple_select("files", "path", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!$folder)
{
$folder['path'] = '/files';
}

$path = "{$folder['path']}/".convert_name($name)."";

$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$count = $db->num_rows($query);

if($count != 0)
{
$errors[] = 'Folder already exists';
}

if(empty($errors))
{
$data = ['name' => $db->escape_string($name), 'description' => $db->escape_string($vk->get_input('description')), 'path' => $db->escape_string($path), 'pid' => $pid, 'time' => TIME_NOW, 'isdir' => 1, 'tag' => $vk->get_input('tag', 1), 'disporder' => $vk->get_input('disporder', 1), 'use_icon' => $vk->get_input('use_icon', 1)];

$fid = $db->insert_query("files", $data);

if($fid)
{
if(!is_dir(VK_ROOT.$path))
{
mkdir(VK_ROOT.$path, 0777, true);
}

if(isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}

echo '<div class="style21">Folder added successfully<br/><a href="'.$vk->settings['url'].'/list/'.$fid.'/'.convert_name($name).'.html">Go to Added Folder</a></div>';
}

}
else
{
show_errors($errors);
}

}

echo '<div class="google_search2">
<form method="post" action="#" enctype="multipart/form-data">
<div class="djnew">
<div>Name:</div>
<div><input type="text" name="name" value="New Folder" maxlength="100" /></div>
</div>
<div class="djnew">
<div>Description:</div>
<div><textarea name="description" /></textarea></div>
</div>
<div class="djnew">
<div>Display Order:</div>
<div><input type="text" name="disporder" value="" /></div>
</div>
<div class="djnew">
<div>Picture (Inside):</div>
<div><input type="file" name="icon" /></div>
</div>
<div class="djnew">
<div>Tag:</div>
<div><input type="radio" name="tag" value="1" /> New <input type="radio" name="tag" value="2" /> Update <input type="radio" name="tag" value="0" checked="sahil" /> No Tag</div>
</div>
<div class="djnew">
<div><input type="hidden" name="action" value="do_add" />
<input type="submit" value="Add" /></div>
</div>
</form>
</div>';
include_once('../footer.php');
