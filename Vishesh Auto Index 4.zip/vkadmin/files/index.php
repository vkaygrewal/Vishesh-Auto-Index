<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once('../inc/init.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = '';
$folder = [];
$pid = $vk->get_input('pid', 1);
$page = isset($vk->input['page']) ? (int)$vk->input['page'] : 1;

if($pid != 0)
{
$query = $db->simple_select("files", "fid, name, use_icon, path, description", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!is_array($folder))
{
header('Location: '.$vk->settings['url']);
exit;
}

$title = $folder['name'];
$folder['name'] = escape($folder['name']);
}
else
{
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
}

include_once('../header.php');



echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187;  <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>File Manager</b></div><br/>';


if($pid == 0)
{
echo '<div id="category"><h1>Select Folder/File</h1></div>';
}
else
{
echo '<div id="category"><h1>'.$folder['name'].'</h1></div>
<div>'.escape($folder['description']).'</div>
<div class="djnew"><a href="'.$vk->settings['adminurl'].'/files/edit.php?fid='.$folder['fid'].'">Edit</a></div>';

if(file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<div class="showimage" align="center"><img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.$folder['name'].'" height="150" width="150" class="absmiddle"/></div>';
}
}

echo '<p class="djnew">&#187;  <a href="'.$vk->settings['adminurl'].'/files/add.php?pid='.$pid.'">Add Folder</a></p>
<p class="djnew">&#187;  <a href="'.$vk->settings['adminurl'].'/upload.php?pid='.$pid.'">Upload File</a></p>';

$query = $db->simple_select("files", "fid", "pid='{$pid}'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($page-1)*$vk->settings['files_per_page'];

$options = ['order_by' => 'time DESC, disporder ASC', 'limit_start' => $start, 'limit' => $vk->settings['files_per_page']];

$query = $db->simple_select("files", "fid, name, isdir, tag, path, size, dcount", "pid='{$pid}'", $options);
while($file = $db->fetch_array($query))
{
if($file['isdir'] == 1)
{
echo '<div class="fl"><a href="'.$vk->settings['adminurl'].'/files/index.php?pid='.$file['fid'].'"><i class="fa fa-folder" aria-hidden="true"></i><div>'.escape($file['name']).'';

if($vk->settings['show_filecount'])
{
$counter = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%' AND `isdir` = '0'");
echo ' ['.$db->num_rows($counter).'] ';
}

if($file['tag'] == 1)
{
echo ' '.vk_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.vk_img('updated.png', "Updated").'';
}

echo '</div></a></div>';
}
else
{
echo '<div class="fl"><a href="'.$vk->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'"><div><div>';

if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else 
{
echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="60" height="65" />';
}
echo '</div><div>'.escape($file['name']).'<br /><span>['.convert_filesize($file['size']).']</span><br /><span></span></div></div></a></div>';
}}

$url = "{$vk->settings['adminurl']}/files/index.php?pid={$pid}&page={page}";
echo pagination($page, $vk->settings['files_per_page'], $total, $url);
}
else
{
echo '<div class="style21">Folder is empty!</div>';
}


if($pid != 0)
{

$_dr = '';

echo '<br/><div class="style21"><a href="'.$vk->settings['url'].'/">Home</a>';

foreach(explode('/', substr($folder['path'], 7)) as $dr)
{
$_dr .= "/".$dr;
$path = "/files{$_dr}";

$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);

if($pid == $id['fid'])
{
echo ' &#187; '.escape($id['name']).'';
}
else
{
echo ' &#187; <a href="'.$vk->settings['adminurl'].'/files/index.php?pid='.$id['fid'].'">'.escape($id['name']).'</a>';
}
}
echo '</div><br/>';
}
include_once('../footer.php');
