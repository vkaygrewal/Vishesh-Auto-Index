<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("../inc/init.php");

include_once(VK_ROOT."inc/class_watermark.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$fid = $vk->get_input('fid', 1);
$message = '';

$query = $db->simple_select("files", "*", "fid='{$fid}'");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$vk->settings['url']}");
exit;
}

if($file['isdir'] == 1)
{
$verb = 'Folder';
}
else
{
$verb = 'File';
}

$title = 'Edit '.$verb.'';
include_once("../header.php");

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/files">File Manager</a> &#187; 
<b>Edit '.$verb.'</b></div><br/>';

echo '<h1>Edit '.$verb.'</h1>';
echo 'Note:- If You Edit A Folder Name please leave blank <span class="style21">"Title, Artist, Category, Label, Lyrics."</span>';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_edit' && $vk->request_method == 'post')
{
$name = $vk->get_input('name');

if($name != $file['name'])
{
$len = strlen($file['name']);
$path = substr($file['path'], 0, -$len);
$path = "{$path}".convert_filename($name)."";

$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$count = $db->num_rows($query);

if($count != 0)
{
$message = 'File/Folder already exists.';
}
}
else
{
$path = $file['path'];
}

$description = $vk->get_input('description');
$title = $vk->get_input('title');
$artist = $vk->get_input('artist');
$lyrics = $vk->get_input('lyrics');
$music = $vk->get_input('music');
$label = $vk->get_input('label');
$tag = $vk->get_input('tag', 1);
$disporder = $vk->get_input('disporder', 1);
$use_icon = $vk->get_input('use_icon', 1);

$data = ['name' => $db->escape_string($name), 'description' => $db->escape_string($description), 'title' => $db->escape_string($title),  'artist' => $db->escape_string($artist),  'lyrics' => $db->escape_string($lyrics), 'music' => $db->escape_string($music), 'label' => $db->escape_string($label), 'disporder' => $disporder, 'tag' => $tag, 'path' => $db->escape_string($path), 'use_icon' => $use_icon];

if(empty($message))
{
$query = $db->update_query("files", $data, "fid='".$fid."'");

if($path != $file['path'])
{
rename(VK_ROOT.$file['path'], VK_ROOT.$path);

if($file['isdir'] == 1)
{
$db->query("UPDATE `".TABLE_PREFIX."files` SET `path`=replace(`path`,'".$db->escape_string($file['path'])."','".$db->escape_string($path)."') WHERE `path` LIKE '".$db->escape_string_like($file['path'])."%'");
}
}

if(isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}

$message = 'File detail updated sucessfully.';

$file['name'] = $name;
$file['description'] = $description;
$file['title'] = $title;
$file['artist'] = $artist;
$file['lyrics'] = $lyrics;
$file['music'] = $music;
$file['label'] = $label;
$file['disporder'] = $disporder;
$file['tag'] = $tag;
}
}

if(isset($vk->input['action']) && $vk->input['action'] == 'remove' && $vk->request_method == 'get')
{
if(unlink(VK_ROOT.'/thumbs/'.$fid.'.png'))
{
$message = 'Icon has been deleted.';
}
else
{
$message = 'Unable to delete Icon.';
}
}

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div>';
}

echo '<div class="google_search2">
<form method="post" action="#" enctype="multipart/form-data">
<div class="djnew">
<div>Name:</div>
<div><input type="text" name="name" value="'.escape($file['name']).'" maxlength="60" /></div>
</div>
<div class="djnew">
<div>Description:</div>
<div><textarea name="description" />'.escape($file['description']).'</textarea></div>
</div>
<div class="djnew">
<div>Title:</div>
<div><input type="text" name="title" value="'.escape($file['title']).'" maxlength="50" /></div>
</div><div class="djnew">
<div>Artist:</div>
<div><input type="text" name="artist" value="'.escape($file['artist']).'" maxlength="50" /></div>
</div><div class="djnew">
<div>Lyrics:</div>
<div><input type="text" name="lyrics" value="'.escape($file['lyrics']).'" maxlength="50" /></div>
</div><div class="djnew">
<div>Category:</div>
<div><input type="text" name="music" value="'.escape($file['music']).'" maxlength="50" /></div>
</div><div class="djnew">
<div>Label:</div>
<div><input type="text" name="label" value="'.escape($file['label']).'" maxlength="50" /></div>
</div><br/>
';

if($file['isdir'] == 1)
{
echo '<div class="djnew">
<div>Display Order:</div>
<div><input type="text" name="disporder" value="'.escape($file['disporder']).'" /></div>
</div>
<div class="toptitle">
<div>Use Icon: </div>
<div><input type="radio" name="use_icon" value="1" '.($file['use_icon'] == 1 ? 'checked ' : '').'/> Yes <input type="radio" name="use_icon" value="0" '.($file['use_icon'] == 0 ? 'checked ' : '').'/> No</div>
</div> ';
}


if(file_exists(''.VK_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<div><img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="" width="80px" height="80px" /><br />
<a href="'.$vk->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&action=remove">Delete Icon</a></div>
';
}
echo'<div class="album_img">
<div>Icon:</div>
<div><input type="file" name="icon" value="" /></div>
</div>';
echo '</div>
<div class="djnew">
<div>Tag:</div>
<div><input type="radio" name="tag" value="1" '.($file['tag'] == 1 ? 'checked ' : '').'/> New <input type="radio" name="tag" value="2" '.($file['tag'] == 2 ? 'checked ' : '').'/> Update <input type="radio" name="tag" value="0" '.($file['tag'] == 0 ? 'checked ' : '').'/> No Tag</div>
</div><br/>
<div>
<div class="google_search2"><input type="hidden" name="action" value="do_edit" />
<input type="submit" value="Edit" /></div>
</div>
</form>
</div>';

if($file['isdir'] == 0)
{
$ext = pathinfo($file['path'], PATHINFO_EXTENSION);

if($ext == 'mp3')
{
echo '<h1>Mp3 Tag Editor</h1>';


if(isset($vk->input['action']) && $vk->input['action'] == 'do_change')
{
$path = VK_ROOT.$file['path'];
mp3tags_writter($path);
}

$tags = get_tags(VK_ROOT.$file['path']);

echo '<div class="google_search2">
<form action="#" method="post" enctype="multipart/form-data">
<div>
<div>Title:</div>
<div><input type="text" name="title" value="'.escape($tags['title']).'" /></div>
</div>
<div>
<div>Artist:</div>
<div><input type="text" name="artist" value="'.escape($tags['artist']).'" /></div>
</div>
<div>
<div>Album:</div>
<div><input type="text" name="album" value="'.escape($tags['album']).'" /></div>
</div>
<div>
<div>Genre:</div>
<div><input type="text" name="genre" value="'.escape($tags['genre']).'" /></div>
</div>
<div>
<div>Year:</div>
<div><input type="text" name="year" value="'.escape($tags['year']).'" /></div>
</div>

<div>
<div>Band:</div>
<div><input type="text" name="band" value="'.escape($tags['band']).'" /></div>
</div>
<div>
<div>Publisher:</div>
<div><input type="text" name="publisher" value="'.escape($tags['publisher']).'" /></div>
</div>
<div>
<div>Composer:</div>
<div><input type="text" name="composer" value="'.escape($tags['composer']).'" /></div>
</div>
<div>
<div>Comment:</div>
<div><input type="text" name="comment" value="'.escape($tags['comment']).'" /></div>
</div>';

if(file_exists(VK_ROOT.$vk->settings['mp3_albumart']))
{
echo '<div>
<div>Default Cover album:</div>
<div><img src="'.$vk->settings['url'].'/'.$vk->settings['mp3_albumart'].'" width="80px" height="80px" /></div>
<div><input type="checkbox" name="image_default" value="1"> Use this image ?</div>
</div>';
}

echo '<div>
<div>Upload Image (jpg, png, or gif only):</div>
<div><input type="file" name="image_file" /></div>
</div>
<div>
<div>Import Image from URL (jpg, png, or gif only):</div>
<div><input type="text" name="image_url" value="" /></div>
</div>
<div>
<div><input type="checkbox" name="image_remove" value="1"> Remove Image Album ?</div>
<div><input type="hidden" name="action" value="do_change" />
<input type="submit" value="Submit" /></div>
</div>
</form>
</div>';
}
}


echo '<p class="djnew">&#187;  <a href="'.$settings['adminurl'].'/files/move.php?fid='.$fid.'">Move '.$verb.'</a></p>';
echo '<p class="djnew">&#187;  <a href="'.$settings['adminurl'].'/files/delete.php?fid='.$fid.'">Delete '.$verb.'</a></p>';

include_once("../footer.php");
