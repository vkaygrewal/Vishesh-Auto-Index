<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("../inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = 'Move';
$fid = $vk->get_input('fid', 1);
$message = '';

$query = $db->simple_select("files", "*", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$vk->settings['url']}");
exit;
}

include_once("../header.php");

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>Move</b></div><br/>';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_move')
{
$path = "/files".$vk->get_input('path');

$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$dirid = $db->fetch_field($query, 'fid');

$real_path = $path."/".basename($file['path']);

$db->update_query("files", ['pid' => $dirid, 'path' => $db->escape_string($real_path)], "fid='".$file['fid']."'");

if($file['path'] != $real_path)
{
if(is_file(VK_ROOT.$file['path']))
{
rename(VK_ROOT.$file['path'], VK_ROOT.$real_path);
}
else
{
dirmv(VK_ROOT.$file['path'], VK_ROOT.$real_path);
$db->query("UPDATE`".TABLE_PREFIX."files` SET `path`=replace(`path`,'".$db->escape_string($file['path'])."','".$db->escape_string($real_path)."') WHERE `path` LIKE '".$db->escape_string_like($file['path'])."%'");
}
$message = 'File/Folder moved sucessfully.';
}
}

echo '<h1>Move Files</h1>';

if(!empty($message))
{
echo '<div class="style21">'.$message.'</div>';
}
echo '<div class="google_search2">
<form method="post" action="#">
<div>Move To:
<div><select name="path">
<option value="">./</option>';

$query = $db->simple_select("files", "path", "isdir=1");
while($folder = $db->fetch_array($query))
{
$folder2 = substr($folder['path'], 6);
if(dirname($file['path']) === $folder['path'])
$selected="selected='vishesh'";
else
$selected='';

echo '<option value="'.$folder2.'"'.$selected.'>'.$folder2.'</option>';
}
echo '</select>/'.basename($file['path']).'</div>
<br/><div><input type="hidden" name="action" value="do_move" />
<input type="submit" value="Move" /></div>
</div></form>
</div>';

include_once('../footer.php');
