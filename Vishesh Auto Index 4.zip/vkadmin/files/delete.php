<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include_once("../inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$fid = $vk->get_input('fid', 1);

$query = $db->simple_select("files", "fid, path", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$vk->settings['url']}");
exit;
}

if(isset($vk->input['action']) && $vk->input['action'] == 'do_delete' && $vk->request_method == 'post')
{
if(is_dir(VK_ROOT.$file['path']))
{
deleteAll(VK_ROOT.$file['path']);

$query = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%'");
while($fi = $db->fetch_array($query))
{
if(file_exists(VK_ROOT.'thumbs/'.$fi['fid'].'.png'))
{
unlink(VK_ROOT.'thumbs/'.$fi['fid'].'.png');
}
}

$db->delete_query("files", "path LIKE '".$db->escape_string_like($file['path'])."%'");
}
else
{
@unlink(VK_ROOT.$file['path']);

if(file_exists(VK_ROOT.'thumbs/'.$fid.'.png'))
{
unlink(VK_ROOT.'thumbs/'.$fid.'.png');
}

$db->delete_query("files", "fid='".$file['fid']."'");
}

header('Location: '.$vk->settings['adminurl'].'/files');
exit;
}

$title = 'Delete File/Folder';
include_once("../header.php");

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/files">File Manager</a> &#187; <b>Delete</b></div><br/>';

echo '<h1>Delete Files</h1>
<div class="google_search2">
<form method="post" action="#">
<div>Do you want to delete?</div>
<div><input type="hidden" name="action" value="do_delete" />
<input type="submit" value="Delete" /> <a href="'.$vk->settings['adminurl'].'/files">No</a></div>
</form>
</div>';

include_once("../footer.php");
