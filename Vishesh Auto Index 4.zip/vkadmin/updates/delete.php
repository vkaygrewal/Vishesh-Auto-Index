<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include("../inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$uid = $vk->get_input('uid', 1);

if(isset($vk->input['action']) && $vk->input['action'] == 'do_delete' && $vk->request_method == 'post')
{
$query = $db->delete_query("updates", "uid='{$uid}'");

header('Location: '.$vk->settings['adminurl'].'/updates/index.php');
exit;
}

$query = $db->simple_select("updates", "uid", "uid='{$uid}'");
$total = $db->num_rows($query);

if($total == 0)
{
header('Location: '.$vk->settings['adminurl'].'');
exit;
}

$title = 'Delete Updates';
include_once('../header.php');
echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates</a> &#187; <b>Delete Updates</b></div>';
echo '<h1>Delete Updates</h1>
<div class="google_search2">
<form method="post" action="#">
<div>Do you want to delete update record?</div>
<div><input type="hidden" name="action" value="do_delete" />
<input type="submit" value="Delete" /> <a href="'.$vk->settings['adminurl'].'/updates/index.php">No</a></div>
</form>
</div>';
include_once('../footer.php');
