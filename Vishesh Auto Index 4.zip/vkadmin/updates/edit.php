<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
define('IN_VK', true);
include("../inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$uid = $vk->get_input('uid', 1);
$message = '';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_edit' && $vk->request_method == 'post')
{
$description = $vk->get_input('description');
$status = $vk->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($description))
{
$data = ['description' => $db->escape_string($description), 'status' => $status];

$db->update_query("updates", $data, "uid='{$uid}'");

$message = 'Update record edited sucessfully.';
}
else
{
$message = 'Please enter update description.';
}
}

$query = $db->simple_select("updates", "description, status", "uid='{$uid}'");
$update = $db->fetch_array($query);

if(!$update)
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = 'Edit Updates';
include_once('../header.php');
echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates</a> &#187; <b>Edit Updates</b></div><br/>'; 

echo '<h1>Edit Update</h1>';

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div>';
}
echo '<div class="google_search2">
<form method="post" action="#">
<div>Description:</div>
<div><textarea name="description">'.escape($update['description']).'</textarea></div>
<div><input type="checkbox" name="status" value="A" '.($update['status'] == 'A' ? 'checked' : '').'> Active(Show on Index)?</div>
<div><input type="hidden" name="action" value="do_edit" />
<input type="submit" value="Edit" /></div>
</form>
</div>';
include_once('../footer.php');
