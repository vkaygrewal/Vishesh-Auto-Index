<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: http://vishesh.cf
Project Version: 4.0
Licence: GPL v3
*/
echo '<div class="header_2"><div id="SC_TBlock_634534" class="SC_TBlock">loading...</div></div>

<div class="headerbottom"> '.date("Y").' &copy;
<a href="'.$vk->settings['adminurl'].'/"><font color="white">'.escape($vk->settings['title']).'</font></a></div></div>
<br/>
Powered by :- <a href="http://www.visheshgrewal.blogspot.com" rel=\"dofollow\" target=\"_blank\" >Vishesh Grewal</a>
<footer>
</footer>
</body>
<script type="text/javascript">
  (sc_adv_out = window.sc_adv_out || []).push({
    id : "634534",
    domain : "n.ads1-adnow.com"
  });
</script>
<script type="text/javascript" src="//st-n.ads1-adnow.com/js/a.js"></script>
</html>';

