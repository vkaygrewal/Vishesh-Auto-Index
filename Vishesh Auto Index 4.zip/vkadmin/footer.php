<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 4.0
Licence: GPL v3
*/
echo '</div><br/>
<div class="headerbottom"> '.date("Y").' &copy;
<a href="'.$vk->settings['adminurl'].'/"><font color="white">'.escape($vk->settings['title']).'</font></a></div>
</body>
</html>';

