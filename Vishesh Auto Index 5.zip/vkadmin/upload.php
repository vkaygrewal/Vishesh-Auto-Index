<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");

include_once(VK_ROOT."/inc/class_watermark.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$fid = 0;
$title = 'Upload File';
$pid = $vk->get_input('pid', 0);

if($pid != 0)
{
$query = $db->simple_select("files", "path", "fid='{$pid}'", "title" );
$path = $db->fetch_field($query, 'path');
}

if(empty($path))
{
$pid = 0;
}

include_once('./header.php');

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187;  <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/files">File Manager</a> &#187; <b>Upload File</b></div><br/>';



echo '<h1>Upload File</h1>';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_upload' && $vk->request_method == 'post')
{
if($pid == 0)
{
$path = '/files'.$vk->get_input('path').'';
}

if(isset($_FILES['file']) && $_FILES['file']['name'] != '')

{
$fid = upload_file('file', $path);
}
elseif(isset($vk->input ['url']) && !empty($vk->input ['url']) && $vk->input ['url'] != 'http://')
{
$fid = import_file($vk->get_input('url'), $path);
}
else
{
echo '<div class="header_2">No file is selected</div>';
}

if($fid > 0 && isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}
}

if(isset($_FILES['title']) && $_FILES['title']['name'] != '')
{}
echo '<div class="google_search2">
<form action="#" method="post"
enctype="multipart/form-data">
<div class="header_2">
<div>Upload File To:</div>';

if($pid != 0)
{
echo '<div>'.escape($path).'</div>';
}

else
{
echo '<div><select name="path">
<option value="">./</option>';

$query = $db->simple_select("files", "path", "isdir=1");
while($folder = $db->fetch_array($query))
{
$folder2 = substr($folder['path'], 6);

echo '<option value="'.$folder2.'">'.$folder2.'</option>';
}

echo '</select></div>';
}

echo '</div>
<div>
<div>Name:</div>
<div><input type="text" name="name" value="" /></div>
</div>
<div class="header_2">
<div>
<div>Select File:</div>
<div><input type="file" name="file" /></div>
</div><br/>
<span class="djnew">OR</span><br/><br/>
<div>
<div>Url:</div>
<div><input type="text" name="url" value="http://" /></div>
</div></div>
<div>
<div>Icon:</div>
<div><input type="file" name="icon"  /></div>
</div>

<div>
<div>Title:</div>
<div><input type="text" name="title"/></div>
</div>

<div>
<div>Description:</div>
<div><textarea name="description"></textarea></div>
</div>
<div>
<div><input type="hidden" name="action" value="do_upload">
<input type="submit" value="Upload" /></div>
</div>
</form>
</div>';
include_once('./footer.php');
