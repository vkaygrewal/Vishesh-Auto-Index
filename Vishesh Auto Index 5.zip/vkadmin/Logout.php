<?php
define('IN_VK', true);
include_once("./inc/init.php");
session_start();
session_destroy();
header('Location: '.$vk->settings['adminurl'].'/index.php');
exit;
?>