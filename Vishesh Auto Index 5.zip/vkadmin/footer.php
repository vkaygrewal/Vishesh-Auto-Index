<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
echo '<br/>
<div class="footer"> '.date("Y").' &copy;
<a href="'.$vk->settings['adminurl'].'/"><font color="white">'.escape($vk->settings['title']).'</font></a>|&nbsp;</div>
</body>
</html>';

