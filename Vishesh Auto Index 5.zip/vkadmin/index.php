<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");
include_once("./header.php");
// Login
if(isset($vk->input['action']) && $vk->input['action'] == 'do_login')
{
$pass = sha1($vk->input['password']);

if($pass == $vk->settings['adminpass'])
{
if($vk->get_input('remember', 1) == 1)
{
vk_setcookie("pass", $pass);
}

$_SESSION['adminpass'] = $pass;
}
else
echo'<div class="header_2"><font size="2px"> 
<i class="fa fa-warning" style="font-size:26px;color:red"></i>You entered wrong password.</font></div>';
}

$title = 'Admin control panel Vishesh Auto Index';
echo'<div class="header_2">';
if(!is_admin())
{
echo '<p class="header">Admin Login</p>
<div class="google_search2">
<form method="post" action="#">
<div>Password:</div>
<div><input type="password" name="password" pattern="[a-z].{1,15,}" /></div>
<div><input type="checkbox" name="remember" value="1" /> Remember Me</div><br/>
<div><input type="hidden" name="action" value="do_login" />
<input type="submit" value="Login" /></div>
</form>
</div></div>';
}
else
{
echo '<div class="header_2"><p class="header">Vishesh Auto Index [Admin Panel]</p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings">Settings Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/ads.php">Ads Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/files"> File Manager</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/editor-more.php">Head Tag, Disclaimer, Policy, Partner Site Editor</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/settings/change.php"> Change Password</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['url'].'/logochange.php"> Change Logo</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/mp3_rename.php">Mass Mp3 Tag Editor</a></p>
<p class="djnew">&#187; <a href="'.$vk->settings['adminurl'].'/scan.php"> Scan Folder</a></p></div></div>';
echo' <p class="djnew">&#187; <a href="https://visheshgrewal.blogspot.com">Vishesh Grewal Blog</a></p>
<p class="djnew">&#187; <a href="https://visheshgrewal.blogspot.com/p/contact-form.html">Send Feedback/Suggestion/Problem Via Email</a></p>
<center><a href="'.$vk->settings['adminurl'].'/Logout.php" class="submit"><button style="font-size: 10px; padding: 10px 24px;border-radius: 8px;">Logout</button></a></center>
';
}
include_once("./footer.php");
