<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once("../inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}
$message = '';
$title = 'Add Updates';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_add' && $vk->request_method == 'post')
{
$description = $vk->get_input('description');
$status = $vk->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($description))
{
$data = ['description' => $db->escape_string($description), 'created_at' => TIME_NOW, 'status' => $status];

$db->insert_query("updates", $data);
$message = 'Update record added successfully.';

header('Location: '.$vk->settings['adminurl'].'/updates/index.php');
}
else
{
$message = 'Please enter update description.';
}
}

include_once('../header.php');

echo '<div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$vk->settings['adminurl'].'/updates">Updates</a> &#187; <b>Add Updates</b></div><br/>';

echo '<h1>Add Update</h1>';

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div>';
}

echo '<div class="google_search2">
<form method="post" action="#">
<div>Description:</div>
<div><textarea name="description"></textarea></div>
<div><input type="checkbox" name="status" value="A" checked /> Active (Show on Index)?
</div>
<div><input type="hidden" name="action" value="do_add" />
<input type="submit" value="Add" /></div>
</form>
</div>';

include_once('../footer.php');
