<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once('../inc/init.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = 'Latest Updates';
include_once('../header.php');

echo '<br/><div class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; <a href="'.$vk->settings['adminurl'].'">Admin Panel</a> &#187; <b>Updates</b></div>';

if(isset($vk->input['page']))
{
$page = (int)$vk->input['page'];
}
else
{
$page = 1;
}

$start = ($page-1)*$vk->settings['updates_per_page'];

$query = $db->simple_select("updates", "uid");
$total = $db->num_rows($query);

echo '<br/><p class="header">Latest Updates</p>
<div class="djnew"><i class="fa fa-plus-circle"></i> <a href="'.$vk->settings['adminurl'].'/updates/add.php">Add New Updates</a></div><br/>
<div class="updates">';

if($total != 0)
{
$options = ['order_by' => 'uid', 'order_dir' => 'desc', 'limit_start' => $start, 'limit' => $vk->settings['updates_per_page']];

$query = $db->simple_select("updates", "uid, description, created_at, status", "", $options);
while($update = $db->fetch_array($query))
{
echo '<div><b><span class="style21">Description</span> :- </b> '.escape($update['description']).'<br/>
<b>Created At:</b> '.date("h:i:s a d-M-y", $update['created_at']).'<br/>
<b>Status:</b> '.(($update['status'] == 'A') ? 'Active' : 'Inactive').'<br/>
<a href="'.$vk->settings['adminurl'].'/updates/edit.php?uid='.$update['uid'].'">Edit</a> | <a href="'.$vk->settings['adminurl'].'/updates/delete.php?uid='.$update['uid'].'">Delete</a></div><br/>';
}
}
else
{
echo '<div>No updates.!</div>';
}
echo '</div>';

$url = "{$vk->settings['adminurl']}/updates/index.php?page={page}";

echo pagination($page, $vk->settings['updates_per_page'], $total, $url);
echo'
<p class="djnew">&#187; <a href="https://visheshgrewal.blogspot.com/p/add-update-on-vishesh-auto-index.html">How To Update <b>[Code]</a></p>';
include_once('../footer.php');
