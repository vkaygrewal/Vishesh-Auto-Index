<?php
@set_time_limit(0);

define('IN_VK', true);
include_once('./inc/init.php');
include_once('../inc/functions.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

include_once('./header.php');

echo '<div class="header">Mass Mp3 Tag Editor</div>';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_change')
{
$path = VK_ROOT.$vk->get_input('path');

$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path),
RecursiveIteratorIterator::SELF_FIRST);
foreach ($files as $file)
{
$ar = explode('.', $file);
if(end($ar) == 'mp3' or end($ar)=='MP3')
{
mp3tags_writter($file);
}
}
}

echo '<div class="google_search2">
<form action="#" method="post">
<div class="label">Path:</div>
<div><input type="text" name="path" value="files" /></div>
<div class="label">Title:</div>
<div><input type="text" name="title" value="" /></div>
<div class="label">Artist:</div>
<div><input type="text" name="artist" value="" /></div>
<div class="label">Album:</div>
<div><input type="text" name="album" value="" /></div>
<div class="label">Genre:</div>
<div><input type="text" name="genre" value="" /></div>
<div class="label">Year:</div>
<div><input type="text" name="year" value="" /></div>
<div class="label">Track:</div>
<div><input type="text" name="track" value="" /></div>
<div class="label">Band:</div>
<div><input type="text" name="band" value="" /></div>
<div class="label">Publisher:</div>
<div><input type="text" name="publisher" value="" /></div>
<div class="label">Composer:</div>
<div><input type="text" name="composer" value="" /></div>
<div class="label">Comment:</div>
<div><input type="text" name="comment" value="" /></div>';

if(file_exists(VK_ROOT.$vk->settings['mp3_albumart']))
{
echo '<div>
<div>Default Cover album:</div>
<div><img src="'.$vk->settings['url'].'/'.$vk->settings['mp3_albumart'].'" width="80px" height="80px" /></div>
<div><input type="checkbox" name="image_default" value="1"> Use this image ?</div>
</div>';
}

echo '<div class="label">Upload Image (jpg, png, or gif only):</div>
<div><input type="file" name="image_file"></div>
<div class="label">Import Image from URL (jpg, png, or gif only):</div>
<div><input size="15" type="text" name="image_url" value="" /></div>
<div><input type="checkbox" name="image_remove" value="1"> Remove All Image Album ?</div>
<div><input type="hidden" name="action" value="do_change" />
<input type="submit" value="Submit" /></div>
</form>
</div>';

include_once('./footer.php');
