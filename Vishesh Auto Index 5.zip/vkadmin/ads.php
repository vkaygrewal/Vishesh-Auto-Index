<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = 'Manage Ads';
$message = '';

include_once('./header.php');
echo '<div class="style21"><a href="'.$settings['url'].'">Home</a> &#187; <a href="'.$settings['adminurl'].'">Admin Panel</a> &#187; <a href="'.$settings['adminurl'].'/ads.php">Ads</a> &#187; <b>Dashboard</b></div><br/>';

echo '<h1>Manage Ads</h1>';

$file = $vk->get_input('file');

if(!empty($file))
{
$ad = VK_ROOT.'assets/ads/'.$file.'.php';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_save' && $vk->request_method == 'post')
{
$fp = fopen($ad, 'w');
fwrite($fp, $vk->input['description']);
$message = 'Ad updated sucessfully.';
}

// Read Ad
$fp = fopen($ad, 'r');
$filesize = filesize($ad);

if($filesize > 0)
{
$content = fread($fp, $filesize);
}
else
{
$content = '';
} 
fclose($fp);

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div><br/>';
}

echo '<div class="google_seaech2">
<form method="post" action="#">
<div><textarea name="description">'.htmlentities($content).'</textarea></div>
<div><input type="hidden" name="action" value="do_save" />
<input type="submit" value="Update Ad" /></div>
</form>
</div><br/>';
}
else
{
$links = [['value' => 'header', 'title' => 'Header'], 
['value' => 'footer', 'title' => 'Footer'],
 ['value' => 'blogo', 'title' => 'Just Below from Logo'], 
['value' => 'acategory', 'title' => 'After Category Title'], 
['value' => 'bcategory', 'title' => 'Before Category Title'], 
['value' => 'afilelist', 'title' => 'After File List'], 
['value' => 'bfilelist', 'title' => 'Before File List'], 
['value' => 'adown', 'title' => 'After Download Link'], 
['value' => 'bdown', 'title' => 'Before Download Link'],
['value' => 'dloadfast', 'title' => 'Download Fast Page'],
['value' => 'aplay', 'title' => 'After Online Player'], 
 ['value' => 'bplay', 'title' => 'Before Online Player']];

foreach($links as $link)
{
echo '<div class="djnew">  &#187; <a href="?file='.$link['value'].'">'.$link['title'].' Ad</a></div><br/>';
}

}


include_once('./footer.php');