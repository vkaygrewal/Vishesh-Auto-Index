<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once("./inc/init.php");

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

$title = 'Manage Template';
$message = '';

include_once('./header.php');
echo '<div class="style21"><a href="'.$settings['url'].'/">Home</a> &#187; <a href="'.$settings['adminurl'].'">Admin Panel</a> &#187;  <a href="'.$settings['adminurl'].'/editor-more.php">Template Editor</a> &#187; <b>Dashboard</b></div><br/>';

echo '<h1>Manage Template</h1>';

$file = $vk->get_input('file');

if(!empty($file))
{
$vtpl = VK_ROOT.'/vishesh/'.$file.'.vk';

if(isset($vk->input['action']) && $vk->input['action'] == 'do_save' && $vk->request_method == 'post')
{
$fp = fopen($vtpl, 'w');
fwrite($fp, $vk->input['description']);
$message = 'Detail updated sucessfully.';
}

// Read file
$fp = fopen($vtpl, 'r');
$filesize = filesize($vtpl);

if($filesize > 0)
{
$content = fread($fp, $filesize);
}
else
{
$content = '';
} 
fclose($fp);

if(!empty($message))
{
echo '<div class="header_2">'.$message.'</div>';
}

echo '<div class="google_search2">
<form method="post" action="#">
<div><textarea name="description">'.htmlentities($content).'</textarea></div>
<div><input type="hidden" name="action" value="do_save" />
<input type="submit" value="Update" /></div>
</form>
</div>';
}
else
{
$links = [['value' => 'header', 'title' => 'Header Meta Tags'], ['value' => 'sponser', 'title' => 'Online Site Partner'], ['value' => 'disclaimer', 'title' => 'Disclaimer Page'], ['value' => 'policy', 'title' => 'Our Policy']];

foreach($links as $link)
{
echo '<div class="djnew">  &#187; <a href="?file='.$link['value'].'">'.$link['title'].' </a></div><br/>';
}

}


include_once('./footer.php');