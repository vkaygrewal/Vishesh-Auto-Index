<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

$title = 'All Updates';
$folder = [];
$page = isset($vk->input['page']) ? (int)$vk->input['page'] : 1;
$folder['name'] = 'Home';
$folder['use_icon'] = 0;

include_once('./header.php');

include_once('./assets/ads/bcategory.php');

echo '<p class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; All Updates</p>';

// Category title
echo '<div class="header">ALL UPDATES</div>
<div class="style3">';

include_once('./assets/ads/acategory.php');
echo'</div>';


$query = $db->simple_select("files", "fid", "isdir='0'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($page-1)*$vk->settings['files_per_page'];

$options = ['order_by' => 'time DESC', 'limit_start' => $start, 'limit' => $vk->settings['files_per_page']];

$query = $db->simple_select("files", "fid, name, title, artist, music, tag, size, path, pid, dcount", "isdir='0'", $options);
while($file = $db->fetch_array($query))
{
if($file['pid'] != 0)
{
$query2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query2);
}

echo '<br/><div> &#187; &nbsp;<b>'.escape($file['music']).' Song &nbsp;</b><i class="fa fa-caret-right"></i>&nbsp; <a href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="djnew" >';

echo '<b>'.escape($file['title']).'</b></a>
<font color="red">['.escape($file['artist']).']</font>';

echo '</div>';
}
$url = "{$vk->settings['url']}/newitems/{page}.html";

echo pagination($page, $vk->settings['files_per_page'], $total, $url);
}
else
{
echo '<br/><div class="style3">No Update Found!</div>';
}

include_once('./assets/ads/afilelist.php');

echo '<br/><p class="dj">&#187; <a href="'.$vk->settings['url'].'"><i class="fa fa-home"></i>&nbsp;Home</a></p>';

include_once('./footer.php');
