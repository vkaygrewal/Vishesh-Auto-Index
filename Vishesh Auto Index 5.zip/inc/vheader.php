<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
error_reporting(0);
if(empty($title))
{
$title = $vk->settings['title'];
}
else
{
$title .= " - {$vk->settings['title']}";
}
$title = escape($title);
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/xml" title="Sitemap" href="sitemap.xml" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0," />
<meta name="author" content="'.$vk->settings['title'].'" /> 
<meta name="revisit-after" content="1 days" /> 
 <meta name="copyright" content="(c) '.$vk->settings['title'].'" /> 
<meta name="distribution" content="global" />
<meta name="classification" content="reference" />
<link href="https://visheshjs.jw.lt/style/vishesh/vishesh.css" type="text/css" rel="stylesheet"/>
<link href="https://visheshjs.jw.lt/style/vishesh/vishesh3.css" type="text/css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
include_once('./vishesh/header.vk');
echo'<body>';
echo'<p class="headertop">&nbsp;<span class="style21"><i class="fa-spin fa fa-globe" aria-hidden="true"></i></span><a href="'.$vk->settings['url'].'"><font color="white">'.$vk->settings['title'].'</font></a></p>';
 



