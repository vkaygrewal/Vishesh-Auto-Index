<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
?>
<br/>
<div class="footer"> <?php echo date('Y'); ?>  &#169; <a href="https://visheshgrewal.blogspot.com/" alt="#"><font color="white">A Vishesh Grewal Project</font></a>|</div>
<script async defer src="https://buttons.github.io/buttons.js"></script>
</body>
</html>

