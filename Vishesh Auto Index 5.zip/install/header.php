<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Vishesh Auto Index Installation Wizard</title>
 <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
<link rel="shortcut icon" href="http://www.vishesh.cf/images/p1.jpg" type="images/x-png"/>
<link href="../style/vishesh.css" type="text/css" rel="stylesheet"/>
<link rel="stylesheet" type="text/css" href="https://visheshjs.jw.lt/style/install.css"/>
<style>
#red{font-weight: bold;
font-family: arial;
font-size: 13px;
color: rgba(131, 131, 131, 1);}
.good{font-weight: bold;
color: rgb(0, 126, 10);
font-size: 13px;
margin: 0px 6px;}
.bad{font-weight: bold;
color: red;
font-size: 13px;
margin: 0px 6px;}
.sep{padding: 2px 0px;
font-size: 13px;
border-bottom: 1px solid #F2F2F2;}
.sep:last-child{border:none}
.pace.pace-inactive {
  display: none;
}

</style>
</head>
<body>

<div class="headertop"> &nbsp; <a href="https://visheshgrewal.blogspot.com"><font color="white">Vishesh Auto Index</font></a></div>
