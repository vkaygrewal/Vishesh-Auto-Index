<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
echo '<br/><div class="header_2">
<div class="header"><center>Installation Wizard<br/>
<span class="style21">Version :- </span><span class="style19">5.0 <span="good">[Only For MP3 Websites]</span></span>
</center></div>
<div class="google_search2">
<form action="#" method="post">
<center>
<div class="red">
<font color="green">DataBase Host:-</font><br/>
<input type="text" name="dbhost" value="localhost" />
<div>Insert your MySQL Database Host. Usually its <em>localhost</em> or <em>mysql.xxxx.ext</em></div>
</div><br/>
<div class="red">
<font color="green">DataBase User:-</font><br/>
<input type="text" name="dbuser" value="" />
<div>Insert your Database User Name</div>
</div><br/>
<div class="red">
<font color="green">DataBase Password:-</font><br/>
<input type="text" name="dbpassword" value="" />
<div>Insert your Database Password</div>
</div><br/>
<div class="red"><br/>
<font color="green">DataBase Name:-</font><br/>
<input type="text" name="dbname" value="" />
<div>Insert your Database Name</div>
</div><br/>
<div class="red">
<font color="green">DataBase Table Prefix:-</font>
<input type="text" name="prefix" value="" />
<div>If you do not know this then keep it blank.</div>
</div><br/>
<div class="red">
<font color="green">WebSite Title:-</font> <br/>
<input type="text" name="title" value="" />
<div>The name of your WebSite</div>
</div><br/>
<div class="red">
<font color="green">WebSite Url:- </font><br/>
<input type="text" name="url" value="http://" />
<div>The full URL to your WebSite <b>without</b> any slash(/) at end.</div>
</div><br/>

<div class="red">
<font color="green">WebSite Logo:- </font><br/>
<input type="text" name="logo" value="/assets/images/logo.png" />
<div>The full URL to your logo. You can always change this later.</div>
</div><br/>
<div class="red">
<font color="green">Admin Password:- </font><br/>
<input type="password" name="adminpass" value="" />
<div>Insert your Admin Password for WebSite Index</div>
</div><br/>
<input type="hidden" name="action" value="do_install" />
<input type="submit" value="Install" /></center>
</form>
</div>
</div>';
