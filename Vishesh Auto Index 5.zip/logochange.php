<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');
include_once('../inc/functions.php');

if(!is_admin())
{
header('Location: '.$vk->settings['url'].'');
exit;
}

include_once('./header.php');

$type = $_POST['type'];

$value = $_POST['valuex'];

$valuex = 20;

$valuey = 10;

$size = $_POST['size'];





if ( $value != '')

{ 

$valuex = $_POST['valuex'];

$valuey = $_POST['valuey'];

}



if ($_POST['type'] == 1)

{

unlink('logo.webp');

copy('././logo.webp','logo.webp');

echo '<div class="valid_box">Default Image Now as Cover</div>';

}



if ($type == 0 )



{

$url = $_POST['url'];



}





if ($url != '')

{

$name = basename($url);       

$ext = pathinfo($url,PATHINFO_EXTENSION);

// to get extension        

$name2 = pathinfo($url,PATHINFO_FILENAME);

//file name without extension

}



$target_dir ="/";

$target_file= "logo.webp"; 

$img = 'image';

$uploadOk =1;

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check if $uploadOk is set to 0 by an error

if ($uploadOk == 0) 

{echo "Sorry, your file was not uploaded.";

// if everything is ok, try to upload file

} 

else {if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) 

{

echo "<div class='header_2'>The file<strong> ".basename( $_FILES["file"]["name"])." </strong>has been uploaded.</div>"; } 

else {echo "";}}



$target = 'logo.webp';

$newcopy = $target;

$w = 500;

$h = 500;

$thumbext = '.jpg';


 


?>



<p class="header">Change Site Logo</p>



<img src="/logo.webp" height="200" width="230"/><br/>

<form action="/logochange.php" enctype="multipart/form-data" method="post"> 

<filedset>

Select File: <br/><div class="google_search2"><input name="file" type="file"/><br/><br/>

 <input name="submit" type="submit" value="Upload"/></div></fieldset> </form>



<br/>

<?php
include_once('./footer.php'); ?>





