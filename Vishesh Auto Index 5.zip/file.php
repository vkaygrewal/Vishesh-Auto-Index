<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);

include_once('./inc/init.php');



$tag = $vk->get_input('tag', 1);

$fid = $vk->get_input('fid');



$query = $db->simple_select("files", "*", "fid={$fid}");

$file = $db->fetch_array($query);



if(!$file)

{

header('Location: '.$vk->settings['url'].'');

exit;

}



$input = VK_ROOT.$file['path'];

$info = pathinfo($input);



$db->query("UPDATE ".TABLE_PREFIX."files SET views=views +1 WHERE fid='".$file['fid']."'");





$title = $file['name'];

include_once('./header.php');





$_dr = '';



echo '<div class="style19"><b><a href="'.$vk->settings['url'].'/">Home</a>';



foreach(explode('/', substr($file['path'], 7)) as $dr)

{

$_dr .= "/".$dr;

$path = "/files{$_dr}";



$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");

$id = $db->fetch_array($query);



if($fid == $id['fid'])

{

echo ' &#187; '.escape($id['name']).'</b>';

}

else

{

echo ' &#187; <a href="'.$vk->settings['url'].'/list/'.$id['fid'].'/'.$vk->settings['sort'].'/1.html">'.escape($id['name']).'</a>';

}

}

echo '</div></b>';


if($vk->settings['show_searchbox'])

{

echo '<div class="google_search2">

<form method="post" action="'.$vk->settings['url'].'/files/search.html">

<input type="text" name="find" size="20" />

<input type="hidden" name="pid" value="'.$pid.'" />

<input type="hidden" name="action" value="do_search" />

<input type="submit" value="Search" />

</form>

</div>';
}
$query = $db->simple_select("files", "*", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query);
echo '<br/><p class="header">Download '.$file['name'].' [<span class="style21">'.$file['artist'].'</span>] </p>
<div id="on" style="">
<table border="0" cellspacing="0" cellpadding="0">
<tr valign="top">
<td> <span class="albumCoverSmall">';
if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'"  width="120" height="65" />';

}

else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))

{

echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="120" height="65" />';

}

else

{

echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="120" height="65"  /></span></td>';

}


echo'<td><div style="float: left;"><div class="albumInfo">
<p class="style18">Title :-<font color="red">'.escape($file['title']).'</font></p>
<p class="style18">Artist :-<font color="red">'.escape($file['artist']).'</font></p>
<p class="style18">lyrics :-<font color="red"> '.escape($file['lyrics']).'</font></p>
<p class="style18">Category :-<font color="red"> '.escape($file['music']).'</font></p>
<p class="style18">Label :-<font color="red">'.escape($file['label']).'</font></p></td></tr></table>
</div></div></div>';

echo'<center><div class="fb-like" data-href="https://facebook.com/'.$vk->settings['fbpagename'].' "data-width="350" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center><br/>';
include_once('./assets/ads/aplay.php');

echo'<p class="header">Share This File</p>
<div class="sharethis-inline-share-buttons"></div>';

if($file['isdir'] == 0)

{

$ext = pathinfo($file['path'], PATHINFO_EXTENSION);

if($ext == 'mp3')

{{

$path = VK_ROOT.$file['path'];

}

echo '<p class="header">Play This Song Online</p>
<audio controls="on/off" src="'.$vk->settings['url'].'/file/download/'.$file['fid'].'.html" type="audio/mpeg" width="70%" border="0"> Your browser does not support the audio tag.</audio>
';

}}

include_once('./assets/ads/bplay.php');



if($vk->settings['related_files'])

{

echo '</div></div><br/><div class="header_2">Recommended For You</div>';



$options = ['order_by' => 'time DESC', 'limit' => $vk->settings['related_files_per_page']];



$query = $db->simple_select("files", "fid, name, title, artist, tag, size, path,  dcount", "pid='{$file['pid']}' AND isdir='0'", $options);

while($rfile = $db->fetch_array($query))

{


echo '<div class="djnew"><br/> &#187; 
<a href="'.$vk->settings['url'].'/download/'.$rfile['fid'].'/'.convert_name($rfile['name']).'.html" alt="#" >

'.escape($rfile['title']).'</a>&nbsp;
<font color="red">['.escape($rfile['artist']).']</font><br/>';


echo '</div>';

}

}


echo'<br/><div class="header">Download File</div>';
include_once('./assets/ads/bdown.php');

if($info['extension'] == 'mp3')
{
$output = "{$info['dirname']}/64kb-{$info['filename']}.{$info['extension']}";
$output2 = "{$info['dirname']}/128kb-{$info['filename']}.{$info['extension']}";
$output3 = "{$info['dirname']}/192kb-{$info['filename']}.{$info['extension']}";
$output4 = "{$info['dirname']}/320kb-{$info['filename']}.{$info['extension']}";

if(file_exists($output))
{
$output = str_replace(VK_ROOT, '', $output);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output.'"><b>Download as 64Kbps</b></a></div>';
}

if(file_exists($output2))
{
$output2 = str_replace(VK_ROOT, '', $output2);

echo '<div><font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output2.'"><b>Download as 128Kbps</b></a></div>';
}

if(file_exists($output3))
{
$output3 = str_replace(VK_ROOT, '', $output3);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output3.'"><b>Download as 192Kbps</b></a></div>';
}

if(file_exists($output4))
{
$output4 = str_replace(VK_ROOT, '', $output4);

echo '<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/'.$output4.'"><b>Download as 320Kbps</b></a></div>';
}

}
echo '<div class="djnew"><font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/file/download/'.$file['fid'].'.html" alt="'.escape($file['name']).'"><b>Download  '.escape($file['title']).'</b></a>&nbsp;[<font color="green"> '.convert_filesize($file['size']).'</font>]
 </div>
<div> <font color="red">&#187; </font> <a href="'.$vk->settings['url'].'/ads.php" alt="'.escape($file['name']).'" ><b>Download '.escape($file['title']).' Fast</b></a> &nbsp;[<font color="green"> '.convert_filesize($file['size']).'</font>]
 </div>';
include_once('./assets/ads/adown.php');
echo'<div class="header">Description</div>
<p class="djnew"><font color="green">'.$file['description'].'</font></p>';


echo '<div class="header">Related Tags</div>

<p class="djnew"><font color="red">'.$file['name'].' Download, '.$file['name'].' Free Download, '.$file['name'].' All Mp3 Song Download, '.$file['name'].' Movies Full Mp3 Songs, '.$file['name'].' video song download, '.$file['name'].' Mp4 HD Video Song Download, '.$file['name'].' Download Ringtone, '.$file['name'].' Movies Free Ringtone, '.$file['name'].' Movies Wallpapers, '.$file['name'].' HD Video Song Download</font></p>';





echo '<p class="dj">&#187; <b><a href="'.$vk->settings['url'].'/index.html">Home</a></b></p>';

include_once('./footer.php');


