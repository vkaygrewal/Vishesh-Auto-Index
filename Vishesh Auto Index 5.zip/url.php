<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

if(preg_match("#url.php#s",''.$_SERVER['REQUEST_URI'].'')){header('HTTP/1.1 301 Moved Permanently'); header('Location: url.txt');}
echo ''.$vk->settings['url'].'</br>
'.$vk->settings['url'].'/files/search.html</br>
'.$vk->settings['url'].'/disclaimer.html</br>
'.$vk->settings['url'].'/top/0.html</br>
'.$vk->settings['url'].'/updates/1.html</br>
'.$vk->settings['url'].'/source.html</br>
'.$vk->settings['url'].'/policy.html</br>';
$vishesh = $db->simple_select("files", "fid", "pid='{$pid}'");
$total = $db->num_rows($vishesh);

if($total != 0)
{$options = ['order_by' => 'isdir DESC, disporder ASC'];
$vishesh = $db->simple_select("files", "fid, name, isdir, tag, path, size, dcount", "pid='{$pid}'", $options);
while($file = $db->fetch_array($vishesh))
{
if($file['isdir'] == 1)
{
echo ''.$vk->settings['url'].'/list/'.$file['fid'].'/'.convert_name($file['name']).'.html</br>';
}
}
}

$vishesh = $db->simple_select("files", "fid", "isdir='0'");
$total = $db->num_rows($vishesh);

if($total != 0)
{

$options = ['order_by' => 'time DESC'];

$vishesh = $db->simple_select("files", "fid, name, tag, size, path, pid, dcount", "isdir='0'", $options);
while($file = $db->fetch_array($vishesh))
{
if($file['pid'] != 0)
{
$vishesh2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($vishesh2);
}
echo ''.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html</br>';
}
}

?>