<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
include_once('./assets/ads/footer.php');

echo'<div class="footer"><a href="'.$vk->settings['url'].'/index.html" alt="Footer"><font color="white">'.$vk->settings['title'].'</font></a>&#169;&nbsp;'; ?>

<?php echo date("Y");?> |
<script>function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}</script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v6.0"></script>
<script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5e9301ce68865d0012fff363&#38;product=inline-share-buttons" async="async"></script>
</html>
</body>