<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
include_once('./inc/vheader.php');
include_once('./assets/ads/header.php');