<?php
/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/
define('IN_VK', true);
include_once('./inc/init.php');

$title = 'Top Files';
$folder = [];
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
$act = $vk->get_input('act',  1);
include_once('./header.php');

include_once('./assets/ads/bcategory.php');

echo '<p class="style21"><a href="'.$vk->settings['url'].'">Home</a> &#187; Top Files</p>';


$options = ['order_by' => 'hits DESC', 'limit' => 20];

switch($act)
{
case '1':
$verb ='Yesterday';
$date = date("dmY",  TIME_NOW-86400);

$query = $db->simple_select("download_history", "fid, hits", "date='{$date}'", $options);
break;

case '2':
$verb ='Week';
$date = date("dmY",  TIME_NOW-604800);

$query = $db->simple_select("download_history", "fid, hits", "date>={$date}", $options);
break;

case '3':
$verb = 'Month';
$date = date("dmY",  TIME_NOW-2592000);

$query = $db->simple_select("download_history", "fid, hits", "date>={$date}", $options);
break;

default:
$verb =' Today ';
$date = date("dmY",  TIME_NOW);

$query = $db->simple_select("download_history", "fid, hits", "date='{$date}'", $options);
break;
}

// Category title
echo '<div class="header">'.$verb.' Top20 Files</div>';

include_once('./assets/ads/acategory.php');

$top_links = [['value' => '1', 'name' => 'Yesterday'], ['value' => '2', 'name' => 'Week'], ['value' => '3', 'name' => 'Month'], ['value' => 0, 'name' => 'Today']];

echo '<div class="style21" align="center">';

$bar = '';

foreach($top_links as $sort_link)
{
echo ''.$bar.'<a href="'.$vk->settings['url'].'/top/'.$sort_link['value'].'.html">'.$sort_link['name'].'</a>';

$bar = ' | ';
}

echo '</div>';

include_once('./assets/ads/bfilelist.php');

$total = $db->num_rows($query);

if($total != 0)
{
while($top = $db->fetch_array($query))
{
$query2 = $db->simple_select("files", "fid, name, title, artist, size, path, pid", "fid='{$top['fid']}'");
$file = $db->fetch_array($query2);

if($file['pid'] != 0)
{
$query2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query2);
}

echo '<div class="fl"><a href="'.$vk->settings['url'].'/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="style20"><div><div>';

if(file_exists(VK_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else if($folder['use_icon'] == 1 && file_exists(VK_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<img src="'.$vk->settings['url'].'/thumbs/'.$folder['fid'].'.png" alt="'.escape($file['name']).'" width="60" height="65" />';
}
else 
{
echo '<img src="'.$vk->settings['url'].'/icon.php?file='.base64_encode($file['path']).'&fid='.$file['fid'].'" alt="'.escape($file['name']).'" width="60" height="65" />';
}

echo '</div><div><b>'.escape($file['title']).'&nbsp;<font color="red">['.escape($file['artist']).']</font></b><br /><span>['.convert_filesize($file['size']).']</span></div></div></a></div>';
}
}
else
{
echo '<br/><div class="style3">No top file At this Time!</div>';
}

include_once('./assets/ads/afilelist.php');

echo '<br/><div class="style21">  &#187;  <a href="'.$vk->settings['url'].'">Home</a></div><br/>';

include_once('./footer.php');
