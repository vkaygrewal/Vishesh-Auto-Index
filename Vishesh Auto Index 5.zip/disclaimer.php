<?php

/*
Project Name: Vishesh Auto Index
Project Vendor: Vishesh Grewal
Project Version: 5
Licence: GPL v3
*/

define('IN_VK', true);
include_once('./inc/init.php');

$title = 'Disclaimer for Content which is published on '.$vk->settings['title'].'';
include_once('./header.php');
include_once('./vishesh/disclaimer.vk');
include_once('./footer.php');